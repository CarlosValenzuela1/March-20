package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Animation;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Player extends Entity {

	private Handler handler;
	private float GRAVITY = .5f;
	private int w = 30, h = 60, MAX_SPEED = 300;
	private EntityId block = EntityId.Block;
	private EntityId stairs = EntityId.Stairs;
	private int numberOfStairs = 0;
	private int playerIsNotInThisStairs = 0;
	private boolean dead = false;
	Texture texture = Game.getInstance();
	private Animation playerWalk;

	public Player(int x, int y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
		
		//Changing 10 changes the speed of animation
		playerWalk = new Animation(5000,  texture.player[0], texture.player[1], texture.player[2], texture.player[3], texture.player[4], texture.player[5], texture.player[6], texture.player[7]);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		x += dx;
		y += dy;

		if(isOnFloor() == false && isOnStairs() == false) {
			GRAVITY = .5f;
			dy += GRAVITY;
			if(dy > MAX_SPEED)
				dy = MAX_SPEED;
		}
		collision();
		playerWalk.runAnimation();
	}

	@Override
	public void render(Graphics g) {
	  if(dx != 0) {
              playerWalk.drawAnimation(g, (int) x, (int) y, 32, 64);
      } else {
              //g.drawImage(texture.player[0], (int) x,(int) y, 32, 64, null);
      }
//		Color color = new Color(20, 20, 20);
//		g.setColor(color);
//		g.fillRect((int) x, (int) y, (int) w, (int) h);
//		
//		Color colorBottom = new Color(70, 70, 70);
//		g.setColor(colorBottom);
//		g.fillRect((int) getBoundsBottom().x, (int) getBoundsBottom().y, (int) getBoundsBottom().width, (int) getBoundsBottom().height);
	}

	private void collision() {
		for(Entity entity : handler.objects) {
			if(entity.getId() == block)
				blockCollision(entity);

			else if(entity.getId() == stairs) {
				stairsCollision(entity);
				
				numberOfStairs += 1;
				if((((Stairs)entity).isPlayerIsHere()) == false)
					playerIsNotInThisStairs += 1;
			}
		}
		if(numberOfStairs == playerIsNotInThisStairs) {
			setOnStairs(false);
		}
		else {
			setOnStairs(true);
			setOnFloor(false);
			setJumping(false);
		}
		numberOfStairs = 0;
		playerIsNotInThisStairs = 0;
	}

	public void jump() {
		if(isJumping() == false)
			setJumping(true);
		setDy(-10);
		setOnFloor(false);
	}

	public void moveRight() {
		setDx(5);
	}

	public void moveLeft() {
		setDx(-5);
	}

	public void moveUp() {
		setDy(-3);
	}

	public void moveDown() {
		setDy(3);
	}

	public void stopMovement() {
		setDx(0);
	}

	private void blockCollision(Entity block) {
		if(getBoundsRight().intersects(block.getBounds()))
			x = block.getX() - w;

		if(getBoundsLeft().intersects(block.getBounds()))
			x = block.getX() + 20;			

		if(getBoundsBottom().intersects(block.getBounds())) {
			y = block.getY() - h;
			setOnFloor(true);
			setOnStairs(false);
			setDy(0);
			setJumping(false);
		} else
			setOnFloor(false);

		if(getBoundsTop().intersects(block.getBounds())) {
			y = block.getY() + 20;
			dy = 0;
		}
	}
	
	private void stairsCollision(Entity stairs) {
		if(getBounds().intersects(stairs.getBounds()))
			((Stairs)stairs).setPlayerIsHere(true);
		else
			((Stairs)stairs).setPlayerIsHere(false);
	}

	public Rectangle getBounds() {
		return new Rectangle((int) x + 5, (int) y + 5, (int) w - 10, (int) h - 10);
	}

	public Rectangle getBoundsBottom() {
		return new Rectangle((int) ((int) x + (w/2) - (w/4)), (int) ((int) y + (h/2)), (int) w/2, (int) h/2);
	}

	public Rectangle getBoundsTop() {
		return new Rectangle((int) ((int) x + (w/2) - (w/4)), (int) y, (int) w/2, (int) h/2);
	}

	public Rectangle getBoundsRight() {
		return new Rectangle((int) ((int) x + w - 5), (int) y + 5, (int) 5, (int) h - 20);
	}

	public Rectangle getBoundsLeft() {
		return new Rectangle((int) x, (int) y + 5, (int) 5, (int) h - 20);
	}

	public boolean isDead() {
		return dead;
	}

	public void setDead(boolean dead) {
		this.dead = dead;
	}
}

