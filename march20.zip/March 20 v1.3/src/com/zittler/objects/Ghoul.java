package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.window.Handler;

public class Ghoul extends Entity{

	private Handler handler;
	private int w = 20, h = 40;
	private int distance = 0;
	private boolean closeToPlayer = false;
	private static final EntityId PLAYER = EntityId.Player;
	private static final EntityId GHOUL = EntityId.Ghoul;
	
	public Ghoul(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		if(isCloseToPlayer() == true) {
			distance ++;
			x -= 3;
		}
		collision(handler);
	}

	@Override
	public void render(Graphics g) {
		Color color = new Color(255, 0, 0);
		g.setColor(color);
		g.fillRect((int) x, (int) y,  w, h);
		
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y,  w, h);
	}

	public void collision(Handler handler) {
		for(Entity entity : handler.objects) {
			if(entity.getId() == PLAYER) {
				setCloseToPlayer(entity);
				if(entity.getBounds().intersects(getBounds())) {
					((Player) entity).setDead(true);
				}
			}
			if(entity.getId() == GHOUL) {
//				if(distance >= 300)
//					handler.removeObject(this);
			}
		}
	}
	
	public void setCloseToPlayer(Entity player) {
		if((x - player.getX()) <= 300 && (y - player.getY() <= 300))
			this.closeToPlayer = true;
		else
			this.closeToPlayer = false;
	}
	
	public boolean isCloseToPlayer() {
		return closeToPlayer;
	}
}
