package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Treasure extends Entity {

	private int w = 40, h = 40;
	Texture texture = Game.getInstance();
	
	public Treasure(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
	}

	@Override
	public void render(Graphics g) {
//		Color color = new Color(184, 61, 186);
//		g.setColor(color);
//		g.fillRect((int) x, (int) y, w, h);
		g.drawImage(texture.treasure[0],(int) x, (int)y, null);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, w, h);
	}

}
