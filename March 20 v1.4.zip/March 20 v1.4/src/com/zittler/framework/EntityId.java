package com.zittler.framework;

public enum EntityId {
	Entity(),
	Player(),
	Stairs(),
	Block(),
	Ghoul(),
	SensitivePlatform(),
	Treasure(),
	Fire(),
	Lance(),
	Bullet(),
	Bee();
}
