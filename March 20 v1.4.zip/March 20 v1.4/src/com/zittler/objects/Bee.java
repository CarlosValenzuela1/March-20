package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Animation;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Bee extends Entity{

	private Handler handler;
	private int w = 20, h = 20;
	private int distanceX = 0, distanceY = 0;
	private boolean closeToPlayer = false;
	Texture texture = Game.getInstance();
	private Animation beeFlying, explosion;
	private int deadDuration = 0;

	
	public Bee(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;	
		beeFlying = new Animation(10, texture.enemies[20], texture.enemies[21]);
		explosion = new Animation(5, texture.explosion[0], texture.explosion[1]);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		if(isCloseToPlayer() == true) {
			moveBee();
			beeFlying.runAnimation();
		}

		if(distanceY > 50) 
			distanceY = 0;

		collision(handler);
		
		if(distanceX > 300) {
			handler.removeObject(this);
		}

	}

	private void moveBee() {
		distanceX ++;
		distanceY ++;
		x -= 3;
		if(distanceY < 25) 
			goDown();
		else
			goUp();
	}
	
	private void goDown() {
		y += 1;
	}
	private void goUp() {
		y -= 1;
	}

	@Override
	public void render(Graphics g) {
//		Color color = new Color(255, 127, 39);
//		g.setColor(color);
//		g.fillRect((int) x, (int) y, w, h);
		if(dead == false)
			beeFlying.drawAnimation(g, (int) x, (int) y, 20, 40);
		
		if(dead == false) {
			if(isCloseToPlayer() == true)
				beeFlying.drawAnimation(g,(int) x, (int) y, 20, 40);
			else
				g.drawImage(texture.enemies[20], (int) x, (int) y, 20, 40, null);
		}
				
		if(isDead() == true && deadDuration > 10) {
			handler.removeObject(this);
		} else if(isDead() == true) {
			explosion.runAnimation();
			explosion.drawAnimation(g, (int) x, (int) y, 20, 20);
			deadDuration++;
		}
			
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y,  w, h);
	}

	public void collision(Handler handler) {
		for(Entity entity : handler.objects) 
			if(entity.getId() == EntityId.Player && this.dead == false) 
				setCloseToPlayer(entity);
	}
	
	
	public void setCloseToPlayer(Entity player) {
		if((x - player.getX()) <= 300 && (y - player.getY() <= 300))
			this.closeToPlayer = true;
		else
			this.closeToPlayer = false;
	}
	
	public boolean isCloseToPlayer() {
		return closeToPlayer;
	}
}
