package com.zittler.framework;

import java.awt.image.BufferedImage;
import java.nio.Buffer;

import com.zittler.window.BufferedImageLoader;

public class Texture {

	SpriteSheet bs, ps, t;
	private BufferedImage blockSheet = null;
	private BufferedImage playerSheet = null;
	private BufferedImage treasureSheet = null;
	
	public BufferedImage[] block = new BufferedImage[2];
	public BufferedImage[] player = new BufferedImage[20];
	public BufferedImage[] fire = new BufferedImage[2];
	public BufferedImage[] treasure = new BufferedImage[2];
	public BufferedImage[] stairs = new BufferedImage[1];
	
	public Texture() {
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			blockSheet = loader.loadImage("/block_sheet_resized.png");
			playerSheet = loader.loadImage("/player_sheet_noborders2.png");
			treasureSheet = loader.loadImage("/treasure_transp.png");
		} catch(Exception e) {
			System.out.println("exit");
			e.printStackTrace();
		}
		
		bs = new SpriteSheet(blockSheet);
		ps = new SpriteSheet(playerSheet);
		t = new SpriteSheet(treasureSheet);
		
		getTextures();
	}
	
	private void getTextures() {
		
		//Brown Floor (Dust)
		block[0] = bs.grabImage(1, 1, 20, 20);
		//Green Floor (Grass)
		block[1] = bs.grabImage(2, 1, 20, 20);
		
		//Fire
		fire[0] = bs.grabImage(3,  1, 20, 20);
		fire[1] = bs.grabImage(3,  1, 20, 20);
		
		//Treasure
		treasure[0] = t.grabImage(1, 1, 40, 40);
		
		//Stairs
		stairs[0] = bs.grabImage(6, 1, 20, 20);
		
		//Character is running RIGHT
		player[0] = ps.grabImage(1, 1, 32, 64);		
		player[1] = ps.grabImage(2, 1, 32, 64);
		player[2] = ps.grabImage(3, 1, 32, 64);
		player[3] = ps.grabImage(4, 1, 32, 64);
		player[4] = ps.grabImage(5, 1, 32, 64);
		player[5] = ps.grabImage(6, 1, 32, 64);
		player[6] = ps.grabImage(7, 1, 32, 64);
		
		//Character is running LEFT
		player[7] = ps.grabImage(1, 2, 32, 64);		
		player[8] = ps.grabImage(2, 2, 32, 64);
		player[9] = ps.grabImage(3, 2, 32, 64);
		player[10] = ps.grabImage(4, 2, 32, 64);
		player[11] = ps.grabImage(5, 2, 32, 64);
		player[12] = ps.grabImage(6, 2, 32, 64);
		player[13] = ps.grabImage(7, 2, 32, 64);
		
		//Character is Jumping Right
		player[14] = ps.grabImage(1, 3, 32, 64);
		player[15] = ps.grabImage(2, 3, 32, 64);
		
		//Character is Jumping Left
		player[16] = ps.grabImage(3, 3, 32, 64);
		player[17] = ps.grabImage(4, 3, 32, 64);
		
		//On Stairs
		player[18] = ps.grabImage(5, 3, 32, 64);
		player[19] = ps.grabImage(6, 3, 32, 64);
	}
}
