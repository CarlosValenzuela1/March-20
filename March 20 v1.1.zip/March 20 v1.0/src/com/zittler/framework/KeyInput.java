package com.zittler.framework;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import com.zittler.objects.Player;
import com.zittler.window.Handler;

public class KeyInput extends KeyAdapter {

	private Handler handler = new Handler();
	private EntityId player = EntityId.Player;
	private int right = KeyEvent.VK_RIGHT;
	private int left = KeyEvent.VK_LEFT;
	private int up = KeyEvent.VK_UP;
	private int down = KeyEvent.VK_DOWN;
	private boolean rightPressed = false;
	private boolean leftPressed = false;
	private boolean jumpPressed = false;
	private int key;

	public KeyInput(Handler handler) {
		this.handler = handler;
	}

	public void keyPressed(KeyEvent e) {
		key = e.getKeyCode();

		for(Entity entity : handler.objects) {
			if(entity.getId() == player) {
				if(key == right) {
					((Player) entity).moveRight();
					setRightPressed(true);
				}

				if(key == left) {
					((Player) entity).moveLeft();
					setLeftPressed(true);
				}

				if(key == KeyEvent.VK_D && entity.isJumping() == false) {
					((Player) entity).jump();
					setJumpPressed(true);
				}
				
				if(key == up && entity.isOnStairs() == true)
					((Player)entity).moveUp();
				
				if(key == down && entity.isOnStairs() == true)
					((Player)entity).moveDown();
					
			}
		}

		if(key == KeyEvent.VK_ESCAPE)
			System.exit(1);
	}

	public void keyReleased(KeyEvent e) {
		key = e.getKeyCode();

		for(Entity entity : handler.objects) {
			if(entity.getId() == player){
				if((key == right) && isLeftPressed() == true) {
					setRightPressed(false);
					((Player) entity).moveLeft();
				} 
				else if (key == right)
					setRightPressed(false);

				if((key == left) && isRightPressed() == true) {
					setLeftPressed(false);
					((Player) entity).moveRight();
				} 
				else if (key == left)
					setLeftPressed(false);

				if((key == right || key == left) && entity.getDx() != 0 && isRightPressed() == false && isLeftPressed() == false) {
					((Player) entity).stopMovement();
				}
				
				if(key == up && entity.isOnStairs())
					entity.setDy(0);
				
				if(key == down && entity.isOnStairs())
					entity.setDy(0);
			}
		}
	}

	public boolean isRightPressed() {
		return rightPressed;
	}

	public void setRightPressed(boolean rightPressed) {
		this.rightPressed = rightPressed;
	}

	public boolean isLeftPressed() {
		return leftPressed;
	}

	public void setLeftPressed(boolean leftPressed) {
		this.leftPressed = leftPressed;
	}

	public boolean isJumpPressed() {
		return jumpPressed;
	}

	public void setJumpPressed(boolean jumpPressed) {
		this.jumpPressed = jumpPressed;
	}
}
