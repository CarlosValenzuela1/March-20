package com.zittler.window;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.zittler.framework.EntityId;
import com.zittler.objects.Block;
import com.zittler.objects.Fire;
import com.zittler.objects.Ghoul;
import com.zittler.objects.Player;
import com.zittler.objects.SensitivePlatform;
import com.zittler.objects.Stairs;

public class BufferedImageLoader {
	private static final EntityId PLAYER = EntityId.Player;
	private static final EntityId BLOCK = EntityId.Block;
	private static final EntityId STAIRS = EntityId.Stairs;
	private static final EntityId GHOUL = EntityId.Ghoul;
	private static final EntityId SENSITIVE_PLATFORM = EntityId.SensitivePlatform;
	private static final EntityId FIRE = EntityId.Fire;
	private BufferedImage image;
	
    public BufferedImage loadImage(String path) {
        try {
                image = ImageIO.read(getClass().getResource(path));
        } catch (IOException e) {
                e.printStackTrace();
        }
        return image;
}
//}

//	public BufferedImage loadImage(String path) throws IOException {
//		return ImageIO.read(getClass().getResource(path));
//	}

	void loadImageLevel(Game game, BufferedImage image) {
		int w = image.getWidth(), h = image.getHeight();
		int pixel, red, green, blue;
		for(int i = 0; i < w - 1; i++) {
			for(int j = 0; j < h - 1; j++) {
				pixel = image.getRGB(i, j);
				red = (pixel >> 16) & 0xff;
				green = (pixel >> 8) & 0xff;
				blue = (pixel) & 0xff;


				if(red == 255 && green == 255 && blue == 255) 	//White
					game.handler.addObject(new Player(i * 20, j * 20, game.handler, PLAYER));

				if(red == 237 && green == 28 && blue == 36) 
					game.handler.addObject(new Stairs(i * 20, j * 20, game.handler, STAIRS));

				if(red == 128 && green == 128 && blue == 128) 
					game.handler.addObject(new Block(i * 20, j * 20, 1, BLOCK));
				
				if(red == 136 && green == 0 && blue == 27)
					game.handler.addObject(new Ghoul(i * 20, j * 20, game.handler, GHOUL));	

				if(red == 185 && green == 122 && blue == 86)
					game.handler.addObject(new SensitivePlatform(i * 20, j * 20, game.handler, SENSITIVE_PLATFORM));
				
				if(red == 255 && green == 127 && blue == 39)
					game.handler.addObject(new Fire(i * 20, j * 20, game.handler, FIRE));
			}
		}
	}
}