package com.zittler.objects;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;

public class GameOver extends Entity {
	
	public GameOver(float x, float y, EntityId id)
	{
		super(x, y, id);
	}
	
	@Override
	public void render(Graphics g) {
		g.setColor(Color.red);
		g.setFont(new Font("Serif", Font.BOLD, 50));
		g.drawString("Game Over", (int) x, (int) y);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		
	}

	@Override
	public Rectangle getBounds() {
		return null;
	}
	
}