package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Window.Type;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Game;

public class Block extends Entity {
	
	private int type;
	Texture texture = Game.getInstance();
	
	public Block(float x, float y, int type, EntityId id) {
		super(x, y, id);
		this.id = id;
		this.type = type;
	}

	@Override
	public void update(LinkedList<Entity> object) {
		
	}

	@Override
	public void render(Graphics g) {
//		Color color = new Color(250, 250, 250);
//		g.setColor(color);
//		g.fillRect((int) x, (int) y, 19, 19);
		if(type == 0)
			g.drawImage(texture.block[0], (int) x, (int) y, null);
		if(type == 1)
			g.drawImage(texture.block[1], (int) x, (int) y, null);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, 20, 20);
	}

}
