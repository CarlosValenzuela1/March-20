package com.zittler.window;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import com.zittler.framework.Camera;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.KeyInput;
import com.zittler.framework.Texture;
import com.zittler.objects.Block;
import com.zittler.objects.Player;

public class Game extends Canvas implements Runnable {

	Handler handler = new Handler();
	EntityId player = EntityId.Player;
	Boolean gameOver = false;
	int gameOverX;
	int gameOverY;
	private static final long serialVersionUID = 1L;
	private boolean running = false;
	private BufferedImage level = null;
	private Thread thread = new Thread();
	private Camera camera = new Camera(0,0);
	private BufferedImageLoader loader = new BufferedImageLoader();
	static Texture texture;

	public static void main(String[] args) {
		new WindowProperties("Test", new Game());
	}

	private void init() throws IOException {
		texture = new Texture();
		loader = new BufferedImageLoader();
		level = loader.loadImage("/level3.png");
		loader.loadImageLevel(this, level);
		//loadImageLevel(level);
		this.addKeyListener(new KeyInput(handler));
		
	}

	private void update() {
		handler.update();
		focusCameraOnPlayer();
	}

	public synchronized void start() {
		if(running)
			return;

		running = true;
		thread = new Thread(this);
		thread.start();
	}

	@Override
	public void run() {
		try {
			init();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.requestFocus();
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0, delta = 0;
		double nanoSeconds = 1000000000 / amountOfTicks;
		long timer = System.currentTimeMillis();

		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / nanoSeconds;
			lastTime = now;
			while(delta >= 1) {
				update();
				delta--;
			}
			render();
			if(System.currentTimeMillis() - timer > 1000) 
				timer += 1000;
		}
	}

	private void render() {
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		Graphics2D g2d = (Graphics2D) g; 
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, getWidth(), getHeight());
		g2d.translate(camera.getX(), camera.getY());
		
		if(gameOver == false)
			handler.render(g);
		else
			g.setColor(new Color(255, 255, 255));
			g.drawString("END", getGameOverX(), getGameOverY());

		g2d.translate(camera.getX(), camera.getY());
		g.dispose();
		bs.show();
	}

	private void focusCameraOnPlayer() {
		for(Entity entity : handler.objects) {
			if(entity.getId() == player) {
				camera.update(entity);
				if(((Player) entity).isDead() == true) {
					setGameOverX((int) entity.getX());
					setGameOverY((int) entity.getY());
					setGameOver(true);	
				}
			}
		}
	}
	
//    private void loadImageLevel(BufferedImage image) {
//        int w = image.getWidth();
//        int h = image.getHeight();
//        int pixel;
//        int red, green, blue;
//        for(int i = 0; i < h; i++) {
//                for(int j = 0; j < w; j++) {
//                        pixel = image.getRGB(i,  j);
//                        red = (pixel >> 16) & 0xff;
//                        green = (pixel >> 8) & 0xff;
//                        blue = (pixel) & 0xff;
//                
//                        if(red == 255 && green == 255 && blue == 255) {
//                                handler.addObject(new Block(i * 32, j * 32, 1, EntityId.Block));
//                        }
//                        
//                        if(red == 128 && green == 128 && blue == 128) {
//                                handler.addObject(new Block(i * 32, j * 32, 0, EntityId.Block));
//                        }
//                        
//                        if(red == 0 && green == 0 && blue == 255) {
//                                handler.addObject(new Player(i * 32, j * 32, handler, EntityId.Player));
//                        }
//                        
//                        
//                }
//        }
//}

	public Boolean getGameOver() {
		return gameOver;
	}

	public void setGameOver(Boolean gameOver) {
		this.gameOver = gameOver;
	}

	public int getGameOverX() {
		return gameOverX;
	}

	public int getGameOverY() {
		return gameOverY;
	}

	public void setGameOverX(int gameOverX) {
		this.gameOverX = gameOverX;
	}

	public void setGameOverY(int gameOverY) {
		this.gameOverY = gameOverY;
	}
	
	public static Texture getInstance(){
		return texture;
	}

}
