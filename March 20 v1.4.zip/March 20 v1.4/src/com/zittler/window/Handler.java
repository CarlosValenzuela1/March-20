package com.zittler.window;

import java.awt.Graphics;
import java.util.LinkedList;

import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;

public class Handler {

	public LinkedList<Entity> objects = new LinkedList<Entity>();
	private Entity entity;

	public void update() {
		for(int i=0; objects.size() > i; i++) {
			Entity entity = objects.get(i);
			if(entity.getId() != EntityId.Treasure)
				entity.update(objects);
		}
	}

	public void render(Graphics g) {
		for(int i=0; objects.size() > i; i++) {
			entity = objects.get(i);
			if(entity.getId() != EntityId.Player)
				entity.render(g);
		}
		
		//So player is render on top of other sprites
		for(int j=0; objects.size() > j; j++) {
				entity = objects.get(j);
				if(entity.getId() == EntityId.Player)
					entity.render(g);
		}	
	}

	public void addObject(Entity object) {
		objects.add(object);
	}

	public void removeObject(Entity object) {
		objects.remove(object);
	}
}
