package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.window.Handler;

public class Stairs extends Entity{

		private float w = 20, h = 20;
		boolean playerIsHere = false;
		public Stairs(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		;
	}

	@Override
	public void render(Graphics g) {
		Color color = new Color(35, 35, 35);
		g.setColor(color);
		g.fillRect((int) x, (int) y, (int) w, (int) h);
	}

	public Rectangle getBounds() {
		return new Rectangle((int) x, (int) y, (int)w , (int) h);
	}

	public boolean isPlayerIsHere() {
		return playerIsHere;
	}

	public void setPlayerIsHere(boolean playerIsHere) {
		this.playerIsHere = playerIsHere;
	}
}
