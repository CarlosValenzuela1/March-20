package com.zittler.framework;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

public abstract class Entity {
	
	protected float x, y, dx = 0, dy = 0;
	protected boolean jumping = false, onStairs = false, onFloor = true;
	protected EntityId id;
	protected boolean dead;
	protected int facing = 1;
	
	public Entity(float x, float y, EntityId id) {
		this.x = x;
		this.y = y;
		this.id = id;
	}
	
	public abstract void update(LinkedList<Entity> objects);
	
	public abstract void render(Graphics g);
	
	public abstract Rectangle getBounds();
	
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	public void setX(float x) {
		this.x = x;
	}
	public void setY(float y) {
		this.y = y;
	}
	public float getDx() {
		return dx;
	}
	public float getDy() {
		return dy;
	}
	public void setDx(float dx) {
		this.dx = dx;
	}
	public void setDy(float dy) {
		this.dy = dy;
	}
	public EntityId getId() {
		return id;
	}
	
	public void setJumping(boolean jumping){
		this.jumping = jumping;
	}
	
	public boolean isJumping() {
		return jumping;
	}
	
	public void setFacing(int facing) {
		this.facing = facing;
	}
	
	public int getFacing() {
		return facing;
	}
	
	public void setOnStairs(boolean onStairs) {
		this.onStairs =  onStairs;
	}
	
	public boolean isOnStairs() {
		return onStairs;
	}
	
	public boolean isOnFloor() {
		return onFloor;
	}

	public void setOnFloor(boolean onFloor) {
		this.onFloor = onFloor;
	}

	public boolean isDead() {
		return dead;
	}

	public void setDead(boolean dead) {
		this.dead = dead;
	}
}
