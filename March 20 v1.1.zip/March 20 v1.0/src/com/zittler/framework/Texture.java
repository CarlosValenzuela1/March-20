package com.zittler.framework;

import java.awt.image.BufferedImage;
import com.zittler.window.BufferedImageLoader;

public class Texture {

	SpriteSheet bs, ps;
	private BufferedImage blockSheet = null;
	private BufferedImage playerSheet = null;
	public BufferedImage[] block = new BufferedImage[2];
	public BufferedImage[] player = new BufferedImage[16];
	public BufferedImage[] fire = new BufferedImage[2];
	public BufferedImage[] treasure = new BufferedImage[1];
	
	public Texture() {
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			blockSheet = loader.loadImage("/block_sheet.png");
			playerSheet = loader.loadImage("/player_sheet_noborders.png");
		} catch(Exception e) {
			System.out.println("exit");
			e.printStackTrace();
		}
		
		bs = new SpriteSheet(blockSheet);
		ps = new SpriteSheet(playerSheet);
		
		getTextures();
	}
	
	private void getTextures() {
		
		//Brown Floor (Dust)
		block[0] = bs.grabImage(1, 1, 32, 32);
		//Green Floor (Grass)
		block[1] = bs.grabImage(2, 1, 32, 32);
		
		//Fire
		fire[0] = bs.grabImage(3,  1, 32, 32);
		fire[1] = bs.grabImage(3,  1, 32, 32);
		
		//Treasure
		treasure[0] = bs.grabImage(5, 1, 32, 32);
		
		//Character is running RIGHT
		player[0] = ps.grabImage(1, 1, 32, 64);		
		player[1] = ps.grabImage(2, 1, 32, 64);
		player[2] = ps.grabImage(3, 1, 32, 64);
		player[3] = ps.grabImage(4, 1, 32, 64);
		player[4] = ps.grabImage(5, 1, 32, 64);
		player[5] = ps.grabImage(6, 1, 32, 64);
		player[6] = ps.grabImage(7, 1, 32, 64);
		
		//Character is running LEFT
		player[7] = ps.grabImage(1, 2, 32, 64);		
		player[8] = ps.grabImage(2, 2, 32, 64);
		player[9] = ps.grabImage(3, 2, 32, 64);
		player[10] = ps.grabImage(4, 2, 32, 64);
		player[11] = ps.grabImage(5, 2, 32, 64);
		player[12] = ps.grabImage(6, 2, 32, 64);
		player[13] = ps.grabImage(7, 2, 32, 64);
		
		//Character is Jumping
//		player[14] = ps.grabImage(1, 3, 32, 64);
//		player[15] = ps.grabImage(2, 3, 32, 64);
	}
}
