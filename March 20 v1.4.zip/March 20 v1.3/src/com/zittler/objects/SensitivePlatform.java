package com.zittler.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.window.Handler;

public class SensitivePlatform extends Entity {
	
	private Handler handler;
	private int w = 10, h = 10;
	private static final EntityId PLAYER = EntityId.Player;
	private boolean treasureExists = false;
	private boolean playerTouchedSensitivePlatform = false;
	
	public SensitivePlatform(float x, float y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		collision(handler);
	}

	@Override
	public void render(Graphics g) {
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle((int) x,(int) y, w, h);
	}
	
	public void collision(Handler handler) {
		for(Entity entity : handler.objects) {
			if(entity.getId() == PLAYER) {
				if(((Player) entity).getBoundsBottom().intersects(getBounds()) && isTreasureExists() == false) {
					setPlayerTouchedSensitivePlatform(true);
					this.x = entity.getX() + 110;
					this.y = entity.getY() + 30;
				}
			}
		}
		
		if(isPlayerTouchedSensitivePlatform() == true && isTreasureExists() == false) {
			System.out.println("Treasure has been created");
			createTreasure(handler);
			setTreasureExists(true);
		}
	}

	public void createTreasure(Handler handler) {
		handler.addObject(new Treasure(x, y, handler, EntityId.Treasure));
	}
	
	public boolean isTreasureExists() {
		return treasureExists;
	}

	public void setTreasureExists(boolean treasureExists) {
		this.treasureExists = treasureExists;
	}
	
	public boolean isPlayerTouchedSensitivePlatform() {
		return playerTouchedSensitivePlatform;
	}

	public void setPlayerTouchedSensitivePlatform(boolean playerTouchedSensitivePlatform) {
		this.playerTouchedSensitivePlatform = playerTouchedSensitivePlatform;
	}
}
