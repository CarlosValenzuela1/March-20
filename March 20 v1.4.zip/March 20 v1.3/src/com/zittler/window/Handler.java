package com.zittler.window;

import java.awt.Graphics;
import java.util.LinkedList;

import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;

public class Handler {

	public LinkedList<Entity> objects = new LinkedList<Entity>();

	public void update() {
		for(int i=0; objects.size() > i; i++) {
			Entity entity = objects.get(i);
			if(entity.getId() != EntityId.Treasure)
				entity.update(objects);
		}
	}

	public void render(Graphics g) {
		for(Entity entity : objects) {
			if(entity.getId() != EntityId.Player) {
				entity.render(g);
			}
		}
		//It puts player on top of any other texture
		for(Entity entity : objects) {
			if(entity.getId() == EntityId.Player) {
				entity.render(g);
			}
		}
			
	}

	public void addObject(Entity object) {
		objects.add(object);
	}

	public void removeObject(Entity object) {
		objects.remove(object);
	}
}
