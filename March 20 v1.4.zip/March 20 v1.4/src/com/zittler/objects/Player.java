package com.zittler.objects;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;
import com.zittler.framework.Entity;
import com.zittler.framework.EntityId;
import com.zittler.framework.Texture;
import com.zittler.window.Animation;
import com.zittler.window.Game;
import com.zittler.window.Handler;

public class Player extends Entity {

	private Handler handler;
	private float GRAVITY = .5f;
	private int w = 30, h = 60, MAX_SPEED = 300;
	private int numberOfStairs = 0;
	private int playerIsNotInThisStairs = 0;
	private int shooting;
	Texture texture = Game.getInstance();
	private Animation playerWalkRight, playerWalkLeft, playerJumpRight, playerJumpLeft, playerOnStairs, playerShootingRight, playerShootingLeft;

	public Player(int x, int y, Handler handler, EntityId id) {
		super(x, y, id);
		this.handler = handler;
		playerWalkRight = new Animation(2,  texture.player[0], texture.player[1], texture.player[2], texture.player[3], texture.player[4], texture.player[5], texture.player[6]);
		playerWalkLeft = new Animation(2, texture.player[7], texture.player[8], texture.player[9], texture.player[10], texture.player[11], texture.player[12], texture.player[13]);
		playerJumpRight = new Animation(8,  texture.player[14], texture.player[15]);
		playerJumpLeft = new Animation(8,  texture.player[16], texture.player[17]);
		playerOnStairs = new Animation(10, texture.player[18], texture.player[19]);
		playerShootingRight = new Animation(10, texture.player[20]);
		playerShootingLeft = new Animation(10, texture.player[21]);
	}

	@Override
	public void update(LinkedList<Entity> objects) {
		if(getFacing() == 1) { 
			if(isShooting() > 0)
				playerShootingRight.runAnimation();
			else if(isJumping() == true)
				playerJumpRight.runAnimation();
			else {
				playerWalkRight.runAnimation();
			}
		}
		else {
			if(isShooting() > 0)
				playerShootingLeft.runAnimation();
			else
			if(isJumping() == true) {
				playerJumpLeft.runAnimation();
			}
			else {
				playerWalkLeft.runAnimation();
			}
		}
		x += dx;
		y += dy;

		if(isOnFloor() == false && isOnStairs() == false) {
			GRAVITY = .5f;
			dy += GRAVITY;
			if(dy > MAX_SPEED)
				dy = MAX_SPEED;
		}
		if(this.isOnStairs() == true) {
			playerOnStairs.runAnimation();
		}
		collision();
	}

	@Override
	public void render(Graphics g) {
		if(this.isOnStairs() == true) {
			if(dy == 0) {
				g.drawImage(texture.player[18], (int) x,(int) y, 32, 64, null);
			} else if (dx >= 1) {
				g.drawImage(texture.player[19], (int) x,(int) y, 32, 64, null);
			} else {
				playerOnStairs.drawAnimation(g, (int) x, (int) y, 32, 64);
			}
		} else if(getFacing() == 1) {
			if(dx == 0 && isJumping() == false && this.isOnStairs() == false && isShooting() == 0) {
				g.drawImage(texture.player[0], (int) x,(int) y, 32, 64, null);
			} else if(isShooting() > 0) {    
				playerShootingRight.drawAnimation(g, (int) x, (int) y, 32, 64);
				shooting++;
				if(shooting > 10) {
					shooting = 0;
				}
			}
			else if (isJumping() == true) {
				playerJumpRight.drawAnimation(g, (int) x, (int) y, 32, 64);
			} else if(dx != 0 && isJumping() == false) {
				playerWalkRight.drawAnimation(g, (int) x, (int) y, 32, 64);
			}  
		} else {
			if(dx == 0 && isJumping() == false && this.isOnStairs() == false && isShooting() == 0) {
				g.drawImage(texture.player[7], (int) x,(int) y, 32, 64, null);
			} else if(isShooting() > 0) {
				playerShootingLeft.drawAnimation(g, (int) x, (int) y, 32, 64);
				shooting++;
				if(shooting > 10) {
					shooting = 0;
				}
			}
			else if(isJumping() == true) {
				playerJumpLeft.drawAnimation(g, (int) x, (int) y, 32, 64);
			} else if(dx != 0 && isJumping() == false) {
				playerWalkLeft.drawAnimation(g, (int) x, (int) y, 32, 64);
			} 
		}
	}

	private void collision() {
		for(int i=0; handler.objects.size() > i; i++) {
			Entity entity = handler.objects.get(i);
			if(entity.getId() == EntityId.Block)
				blockCollision(entity);

			else if(entity.getId() == EntityId.Stairs) {
				stairsCollision(entity);
				numberOfStairs += 1;
				if((((Stairs)entity).isPlayerIsHere()) == false)
					playerIsNotInThisStairs += 1;
			}
			else if(entity.getId() == EntityId.Ghoul)
				enemyCollision(entity);
			
			else if(entity.getId() == EntityId.Bee)
				enemyCollision(entity);
				
		}
		if(numberOfStairs == playerIsNotInThisStairs) {
			setOnStairs(false);
		}
		else {
			setOnStairs(true);
			setOnFloor(false);
			setJumping(false);
		}
		numberOfStairs = 0;
		playerIsNotInThisStairs = 0;
	}

	public void jump() {
		if(isJumping() == false)
			setJumping(true);
		setDy(-10);
		setOnFloor(false);
	}

	public void moveRight() {
		setDx(5);
		setFacing(1);
	}

	public void moveLeft() {
		setFacing(-1);
		setDx(-5);
	}

	public void moveUp() {
		setDy(-3);
	}

	public void moveDown() {
		setDy(3);
	}

	public void stopMovement() {
		setDx(0);
	}

	private void blockCollision(Entity block) {
		if(getBoundsRight().intersects(block.getBounds()))
			x = block.getX() - w;

		if(getBoundsLeft().intersects(block.getBounds()))
			x = block.getX() + 20;			

		if(getBoundsBottom().intersects(block.getBounds())) {
			setOnFloor(true);
			y = block.getY() - h;
			setOnStairs(false);
			setDy(0);
			setJumping(false);
		} else
			setOnFloor(false);

		if(getBoundsTop().intersects(block.getBounds())) {
			y = block.getY() + 20;
			dy = 0;
		}
	}
	
	private void stairsCollision(Entity stairs) {
		if(getBounds().intersects(stairs.getBounds()))
			((Stairs)stairs).setPlayerIsHere(true);
		else
			((Stairs)stairs).setPlayerIsHere(false);
	}
	
	private void enemyCollision(Entity enemy) {
		if(getBounds().intersects(enemy.getBounds())) {
			enemy.setDead(true);
			this.setDead(true);
		}
	}

	public Rectangle getBounds() {
		return new Rectangle((int) x + 5, (int) y + 5, (int) w - 10, (int) h - 10);
	}

	public Rectangle getBoundsBottom() {
		return new Rectangle((int) ((int) x + (w/2) - (w/4)), (int) ((int) y + (h/2)), (int) w/2, (int) h/2);
	}

	public Rectangle getBoundsTop() {
		return new Rectangle((int) ((int) x + (w/2) - (w/4)), (int) y, (int) w/2, (int) h/2);
	}

	public Rectangle getBoundsRight() {
		return new Rectangle((int) ((int) x + w - 5), (int) y + 5, (int) 5, (int) h - 20);
	}

	public Rectangle getBoundsLeft() {
		return new Rectangle((int) x, (int) y + 5, (int) 5, (int) h - 20);
	}

	public int isShooting() {
		return shooting;
	}

	public void setShooting(int shooting) {
		this.shooting = shooting;
	}
}

